import React from 'react'
// import image from "../../Component/image/exe.jfif"
import style from "../../StyleSheet/About/About.module.css"


export const About = () => {
    return (
        <>
        <div className={style["exercise"]}>
            <div className={style["image_di"]}>
              
            </div>
        </div>
           
        </>
    )
};
export default About;
