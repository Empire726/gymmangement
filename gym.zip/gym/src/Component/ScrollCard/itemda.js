 export const Itemda =[
    {
    img:"images/gym1.png",
    title:" Custom Theme with Angular Material",
    name:"item",

    },
     {
    img:"images/gym2.png",
    title:" Custom Theme with Angular Material",
    name:"item",

    },
     {
    img:"images/gym3.png",
    title:" Custom Theme with Angular Material",
    name:"item",

    },
     {
    img:"images/gym4.png",
    title:" Custom Theme with Angular Material",
    name:"item",

    },
     {
    img:"images/gym5.png",
    title:" Custom Theme with Angular Material",
    name:"item",

    },
     {
    img:"images/gym6.png",
    title:" Custom Theme with Angular Material",
    name:"item",

    },
     {
    img:"images/gym7.png",
    title:" Custom Theme with Angular Material",
    name:"item",

    },
     {
    img:"images/gym8.png",
    title:" Custom Theme with Angular Material",
    name:"item",

    },
]