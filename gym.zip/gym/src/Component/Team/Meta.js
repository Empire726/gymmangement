export const Meta =[

{
    image:"images/pp.jfif",
    Nam:"Naveen kumar",
    Pro:" Developer",
},

{
    image:"images/Team.jpeg",
    Nam:"Kapil kumar",
    Pro:" Developer",
},
{
    image:"images/tm1.JPG",
    Nam:"Naveen kumar",
    Pro:" Developer",
},

]