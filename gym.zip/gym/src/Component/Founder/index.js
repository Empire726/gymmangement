import React from 'react'

export const Founder = () => {
    return (
        <div>
            Founder
        </div>
    )
}
export default Founder;

