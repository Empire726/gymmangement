export const MenuItems = [
    {
        title: 'Home',
        url: '/',
        cName: 'nav-links'
    },
    {
        title: "Team",
        url: '/team',
        cName: 'nav-links'
    },
    {
        title: 'Exercise',
        url: '/workout',
        cName: 'nav-links'
    },
    {
        title: 'ContactUs',
        url: '/contact',
        cName: 'nav-links'
    },
    // {
    //     title: 'Sign up',
    //     url: '#',
    //     cName: 'nav-links-mobile'
    // }
]