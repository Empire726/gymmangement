import React from 'react'

const Fronts = () => {
    return (
        <>

        
            
        </>
    )
}

export default Fronts
