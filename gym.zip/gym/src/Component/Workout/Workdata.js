export const Workdata =
    [
        {
            img:"images/cab--.gif",
            para:"Fitness",
        },
        {
            img: "images/cab--1.gif",
            para:"Fitness",
        },
        {
            img: "images/cable--2.gif",
            para:"Fitness",
        },
        {
            img: "images/cable--3.gif",
            para:"Fitness",
        },
        {
            img: "images/cable--4.gif",
            para:"Fitness",
        },
        {
            img: "images/cable-5.gif",
            para:"Fitness",
        },
        {
            img: "images/cable--str.gif",
            para:"Fitness",
        },
        {
            img: "images/caption.gif",
            para:"Fitness",
        },
        {
            img: "images/crun.gif",
            para:"Fitness",
        },
        {
            img: "images/crunch-floor.gif",
            para:"Fitness",
        },
        {
            img: "images/down.gif",
            para:"Fitness",
        },
        {
            img: "images/down-1.gif",
            para:"Fitness",
        },
        {
            img: "images/down-to.gif",
            para:"Fitness",
        },
        {
            img: "images/exercise-1.gif",
            para:"Fitness",
        },
        {
            img: "images/front-plank.gif",
            para:"Fitness",
        },
        {
            img: "images/hips-rise.gif",
            para:"Fitness",
        },
        {
            img: "images/hunder.gif",
            para:"Fitness",
        },
        {
            img: "images/push.gif",
            para:"Fitness",
        }, {
            img: "images/strech.gif",
            para: "Fitness",
        },
        {
            img: "images/work.gif",
            para: "Fitness",
        },
        {
            img: "images/work-1.gif",
            para: "Fitness",
        },

    ]
