import React from 'react'
import "../../StyleSheet/Front/front.css"



const Front = () => {
    return (
        <>
            <div className="animated">
                <div className="animats">
                    
                
            </div>
              </div>       

        </>
    )
}

export default Front;
