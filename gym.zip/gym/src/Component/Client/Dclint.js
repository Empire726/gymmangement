export const Dclint = [
  {
    imgs: "images/client.jpg",

  },
  {
    imgs: "images/client-1.jpg",

  },
  {
    imgs: "images/client-2.jpg",

  },
  {
    imgs: "images/client-3.jpg",

  },
  {
    imgs: "images/client-4.jpg",

  },

  {
    imgs: "images/client-5.jpg",

  },
   {
    imgs: "images/client-6.jpg",

  },
  {
    imgs: "images/client-7.jpg",

  },
  {
    imgs: "images/client-8.jpg",

  },
  {
    imgs: "images/client-9.jpg",

  },
  {
    imgs: "images/client-10.jpg",

  },

  {
    imgs: "images/client-11.jpg"

  },
  {
    imgs: "images/client-2.jpg",

  },
  {
    imgs: "images/client-3.jpg",

  },
  {
    imgs: "images/client-9.jpg",

  },
]
