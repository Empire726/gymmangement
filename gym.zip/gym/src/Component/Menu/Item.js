export const Item = [
    {
        imgsrc:"images/gym.png",
        head:"BURN FAT 1",
        title:"5 DAY workout"
    },
     {
        imgsrc:"images/gym.png",
        head:"BURN FAT 2",
        title:"10 DAY workout"
    },
     {
        imgsrc:"images/gym.png",
        head:"BURN FAT 3",
        title:"7 DAY workout"
    },
     {
        imgsrc:"images/gym.png",
        head:"BURN FAT 4",
        title:"10 DAY workout"
    },
     {
        imgsrc:"images/gym.png",
        head:"BURN FAT 5",
        title:"15 DAY workout"
    },
    
     {
        imgsrc:"images/gym.png",
        head:"BURN FAT 6",
        title:"20 DAY workout"
    },
]