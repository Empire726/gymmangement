import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import Header2 from './Component/Header/index ';



ReactDOM.render(
  <>
 <Header2 />

    <App />
    </>,
    
  document.getElementById('root')
);
